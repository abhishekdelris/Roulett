import React from "react";
import "./Roulette.css"; // Import your custom styles
import RouletteWheel from "./Roulettewheel";
import Wheel from '../assets/img/game/wheel.gif';
import BgWheel from '../assets/img/game/bgwheel.gif';
import Score from '../assets/img/home/score.png'
import Timer from '../assets/img/home/timer.png'
import Winner from '../assets/img/home/Winner.png'
import Ten from '../assets/img/home/10.svg'
import Twonty from '../assets/img/home/20.svg'
import Fifty from '../assets/img/home/50.svg'
import Hundred from '../assets/img/home/100.svg'
import TwoHundred from '../assets/img/home/200.svg'
import FiveHundred from '../assets/img/home/500.svg'
import Thousand from '../assets/img/home/1000.svg'

const RouletteGame = () => {
  return (
    <div className="game-screen bettingBg text-white h-screen p-6">
      <div className="container mx-auto">
        {/* <div className="flex flex-wrap">
        
          <div className="w-full  px-4 mb-4">
            <header className="flex justify-between items-center mb-4">
              <div className="balance">
                Your Balance: <span className="font-bold">10,000</span>
              </div>
              <div className="bet-amount">
                Bet Amount: <span className="font-bold">600</span>
              </div>
            </header>
          </div>
          </div> */}
        <div className="flex flex-wrap">

          {/* Game Body */}
          <div className="w-full md:w-1/2 lg:w-1/4 px-4 mb-4">
          </div>
          <div className="w-full md:w-1/2 lg:w-3/4 px-4 mb-4">
          {/* Score, Timer, Winner */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                <div className="text-center"><img src={Score} alt="score" className="w-20"/></div>
                <div className="text-center"><img src={Timer} alt="timer" className="w-20"/></div>
                <div className="text-center"><img src={Winner} alt="winner" className="w-20"/></div>
              </div>

              {/* Chips and Betting Options */}
              <div className="chips flex justify-center mb-2 space-x-4">
                <div className="chip w-10 h-10 rounded-full "><img src={Ten} alt="Ten" className="w-10"/></div>
                <div className="chip w-10 h-10 rounded-full"><img src={Twonty} alt="Twonty" className="w-10"/></div>
                <div className="chip w-10 h-10 rounded-full"><img src={Fifty} alt="Fifty" className="w-10"/></div>
                <div className="chip w-10 h-10 rounded-full"><img src={Hundred} alt="Hundred" className="w-10"/></div>
                <div className="chip w-10 h-10 rounded-full"><img src={TwoHundred} alt="TwoHundred" className="w-10"/></div>
                <div className="chip w-10 h-10 rounded-full"><img src={FiveHundred} alt="FiveHundred" className="w-10"/></div>
                <div className="chip w-10 h-10 rounded-full"><img src={Thousand} alt="Thousand" className="w-10"/></div>
              </div>
          </div> 
          <div className="w-full md:w-1/2 lg:w-1/4 px-4 mb-4">
            {/* Roulette Wheel */}
            <div className="roulette-wheel">
            <img src={BgWheel} alt="Background Wheel" className="bg-wheel" />
            <img src={Wheel} alt="Wheel" className="overlay-wheel" />
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2">
          {/* Add any pointer/indicator here */}
          <div className="w-4 h-4"><svg width="25" height="25" viewBox="0 0 66 96" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M56.8591 10.1015C50.5075 3.76174 42.0501 0.273441 33.0311 0.273441C23.9999 0.269534 15.5392 3.76174 9.19915 10.1015C-10.7698 30.0785 9.42962 60.9885 24.1792 83.5585C26.6597 87.3476 28.9995 90.9296 30.8784 94.0705C31.3276 94.8205 32.1478 95.2893 33.0267 95.2893C33.9056 95.2893 34.7259 94.8206 35.1751 94.0705C37.054 90.9299 39.3939 87.3517 41.8743 83.5585C56.6283 60.9885 76.8281 30.0785 56.8591 10.1015ZM47.1287 33.9295C47.1287 41.7107 40.8005 48.0315 33.0266 48.0315C25.2454 48.0315 18.9247 41.7112 18.9247 33.9295C18.9247 26.1478 25.2449 19.8275 33.0266 19.8275C40.8 19.8275 47.1287 26.1478 47.1287 33.9295Z" fill="#FBBC05"/>
</svg>
</div>
        </div>
                {/* <RouletteWheel /> */}
            </div>
          </div>

          <div className="w-full md:w-1/2 lg:w-3/4 px-4 mb-4">
            {/* Betting Grid */}
            <div className="betting-table p-4 rounded-lg">
              {/* Betting Table */}
              <table className="table-auto w-full text-center number-table">
                <tbody>
                  <tr>
                   <td rowSpan={4}><div className="bet-item-inner bg-red-600">0</div></td>
                  </tr>
                  <tr>
                    <td><div className="bet-item-inner bg-red-600">3</div></td>
                    <td><div className="bet-item-inner bg-black">6</div></td>
                    <td><div className="bet-item-inner bg-red-600">9</div></td>
                    <td><div className="bet-item-inner bg-red-600">12</div></td>
                    <td><div className="bet-item-inner bg-black">15</div></td>
                    <td><div className="bet-item-inner bg-red-600">18</div></td>
                    <td><div className="bet-item-inner bg-red-600">21</div></td>
                    <td><div className="bet-item-inner bg-black">24</div></td>
                    <td><div className="bet-item-inner bg-red-600">27</div></td>
                    <td><div className="bet-item-inner bg-red-600">30</div></td>
                    <td><div className="bet-item-inner bg-black">33</div></td>
                    <td><div className="bet-item-inner bg-red-600">36</div></td>
                    <td><div className="bet-item-inner text-wrning">72</div></td>
                  </tr>
                  <tr>
                    <td><div className="bet-item-inner bg-black">2</div></td>
                    <td><div className="bet-item-inner bg-red-600">5</div></td>
                    <td><div className="bet-item-inner bg-black">8</div></td>
                    <td><div className="bet-item-inner bg-black">11</div></td>
                    <td><div className="bet-item-inner bg-red-600">14</div></td>
                    <td><div className="bet-item-inner bg-black">17</div></td>
                    <td><div className="bet-item-inner bg-black">20</div></td>
                    <td><div className="bet-item-inner bg-red-600">23</div></td>
                    <td><div className="bet-item-inner bg-black">26</div></td>
                    <td><div className="bet-item-inner bg-black">29</div></td>
                    <td><div className="bet-item-inner bg-red-600">32</div></td>
                    <td><div className="bet-item-inner bg-black">35</div></td>
                    <td><div className="bet-item-inner text-wrning">72</div></td>
                  </tr>
                  <tr>
                    <td><div className="bet-item-inner bg-red-600">1</div></td>
                    <td><div className="bet-item-inner bg-black">4</div></td>
                    <td><div className="bet-item-inner bg-red-600">7</div></td>
                    <td><div className="bet-item-inner bg-black">10</div></td>
                    <td><div className="bet-item-inner bg-black">13</div></td>
                    <td><div className="bet-item-inner bg-red-600">16</div></td>
                    <td><div className="bet-item-inner bg-red-600">19</div></td>
                    <td><div className="bet-item-inner bg-black">22</div></td>
                    <td><div className="bet-item-inner bg-red-600">25</div></td>
                    <td><div className="bet-item-inner bg-black">28</div></td>
                    <td><div className="bet-item-inner bg-black">31</div></td>
                    <td><div className="bet-item-inner bg-red-600">34</div></td>
                    <td><div className="bet-item-inner text-wrning">72</div></td>
                  </tr>
                  <tr className="table-bottom">
                    <td className="border-0"></td>
                    <td colSpan={4}><div className="">1 TO 18</div></td>
                    <td colSpan={4}><div className="">2 NO 12</div></td>
                    <td colSpan={4}><div className="">3 RO 12</div></td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="flex flex-wrap">
              <div className=""></div>
              <div className=""></div>
              <div className=""></div>
              <div className=""></div>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};

export default RouletteGame;
